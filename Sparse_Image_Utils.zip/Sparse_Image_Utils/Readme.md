#######################
********************************
Sparse IMG Utils for Termux Packages.
********************************
Compiled by @genxster for poor fellas .
having no PC.
credits :- anestsb ; Meizu devs Karl Zheng ; Genxster
#######################
⚫ Instructions :


1.Make sure you have installed  python first ,i.e have python environment setup already .
2.Simg2img.py creates extra raw img  in Termux  ~  as Temp.img .